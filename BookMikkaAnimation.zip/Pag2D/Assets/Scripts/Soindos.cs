﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Soindos : MonoBehaviour {


    public void ReproducirSonidos()
    {
        GetComponent<AudioSource>().Play();
    }
}
