﻿using UnityEngine;
using System.Collections;

public class Puertas {

	public int cantidad;
	public bool cerrojo;
}
