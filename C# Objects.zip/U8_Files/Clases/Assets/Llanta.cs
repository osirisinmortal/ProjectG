﻿using UnityEngine;
using System.Collections;

public class Llanta  {

	public int cantidadTornillos;
}
