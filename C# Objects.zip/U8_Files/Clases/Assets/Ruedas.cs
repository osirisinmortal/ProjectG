﻿using UnityEngine;
using System.Collections;

public class Ruedas {

	public int grosor;
	public int cantidad;
	public enum ColorRueda {azul, negra, roja , verde}
	public ColorRueda colorRueda;
	public Llanta llanta = new Llanta();

}
